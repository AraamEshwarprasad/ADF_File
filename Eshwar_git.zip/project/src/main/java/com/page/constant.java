package com.page;

public class constant
{
	public final static String HomePageUrl="https://www.audio-digest.org/";

	public final static String LoginPageurl="https://www.audio-digest.org/Login";

	public final static String DashBoardPageUrl="https://www.audio-digest.org/Dashboard";

	public final static String PlayListUrl="https://www.audio-digest.org/Playlists";

	public final static String libraryUrl="https://www.audio-digest.org/Library";

	//public final static String updated_Playlist_Name="playlist01";

	//public final static String speciality="Neurology";

	public final static String playlist_Name="myplaylist";

	public final static String emailId="on_silver@wk.com";

	public final static String password="!QAZxsw2";
}
